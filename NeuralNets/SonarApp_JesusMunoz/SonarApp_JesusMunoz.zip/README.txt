README

run python sonarApp.py

make sure to install any dependencies needed!
